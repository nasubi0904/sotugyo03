from __future__ import annotations

"""
DateGridNode

- 他ノードを「背景グリッド」上に縦方向へスナップ配置するノード。
- DateGridNode 自身は常に他ノードの背面に描画される（Z 値を低く設定）。
- スナップされたノードの情報は snap_nodes プロパティとして保持する。
"""

from typing import List

from PySide2.QtCore import QRectF
from PySide2.QtGui import QColor

from .base_nodes import ToolBaseNode  # 共通ベースノード


class DateGridNode(ToolBaseNode):
    __identifier__ = "KDM"
    NODE_NAME = "DateGrid"

    def __init__(self) -> None:
        super(DateGridNode, self).__init__()

        # 見た目
        self.set_color(80, 90, 120)
        # 常に背面に描画
        try:
            self.set_z_value(-1000)
        except Exception:
            pass

        # レイアウト用パラメータ
        self._padding_x: float = 20.0   # 左端からのオフセット
        self._padding_y: float = 40.0   # 上端からのオフセット
        self._snap_margin: float = 10.0  # 外周からのマージン

        # スナップされているノード ID のリスト（内部用。Inspector には出さない）
        self.create_property(
            name="snap_nodes",
            value=[],
            widget_type=None,
            tab="Date Grid",
            widget_tooltip="この DateGrid にスナップされているノードの ID リスト",
        )

    # --------------------------------------------------------
    # 描画（背景を半透明の帯にする）
    # --------------------------------------------------------
    def paint(self, painter, option, widget) -> None:
        # デフォルトのノード描画
        super(DateGridNode, self).paint(painter, option, widget)

        # その上に半透明の帯を描画
        rect = self.boundingRect()
        painter.save()
        painter.setBrush(QColor(50, 60, 90, 40))
        painter.setPen(QColor(0, 0, 0, 0))
        painter.drawRect(rect)
        painter.restore()

    # --------------------------------------------------------
    # グリッド領域（スナップ判定用）の矩形
    # --------------------------------------------------------
    def snap_rect(self) -> QRectF:
        """
        DateGrid 全体から _snap_margin 分だけ内側をスナップ有効領域とする。
        """
        br = self.sceneBoundingRect()
        return QRectF(
            br.x() + self._snap_margin,
            br.y() + self._snap_margin,
            br.width() - self._snap_margin * 2.0,
            br.height() - self._snap_margin * 2.0,
        )

    # --------------------------------------------------------
    # ノードがスナップ領域内に入っているか
    # --------------------------------------------------------
    def is_inside(self, node) -> bool:
        node_rect = node.sceneBoundingRect()
        return self.snap_rect().intersects(node_rect)

    # --------------------------------------------------------
    # ノードの登録
    # --------------------------------------------------------
    def add_snap_node(self, node) -> None:
        children: List[str] = self.get_property("snap_nodes") or []
        if node.id in children:
            return
        children.append(node.id)
        self.set_property("snap_nodes", children)
        self.layout_children()

    # --------------------------------------------------------
    # ノードの解除
    # --------------------------------------------------------
    def remove_snap_node(self, node) -> None:
        children: List[str] = self.get_property("snap_nodes") or []
        if node.id not in children:
            return
        children.remove(node.id)
        self.set_property("snap_nodes", children)
        self.layout_children()

    # --------------------------------------------------------
    # 縦方向へ整列
    # --------------------------------------------------------
    def layout_children(self) -> None:
        """
        snap_nodes に登録されているノードを
        DateGrid 内部に縦一列で並べ、高さも自動調整する。
        """
        graph = self.graph
        if not graph:
            return

        children: List[str] = self.get_property("snap_nodes") or []
        if not children:
            return

        y = float(self.pos().y()) + self._padding_y
        x = float(self.pos().x()) + self._padding_x

        for nid in children:
            child = graph.get_node_by_id(nid)
            if not child:
                continue

            # 子ノードを縦に並べる
            child.set_pos(x, y)

            # child.height が無い場合は 60 くらいを仮定
            h = getattr(child, "height", 60.0)
            y += float(h) + 6.0

        # DateGrid 自身の高さを子ノード列に合わせて伸ばす
        new_h = max(float(self.height), y - float(self.pos().y()) + self._padding_y)
        self.set_property("height", new_h)

    # --------------------------------------------------------
    # メイン処理：ノード移動時に呼ばれるクラスメソッド
    # --------------------------------------------------------
    @classmethod
    def on_node_moved(cls, graph, moved_node) -> None:
        """
        NodeGraph.property_changed("pos") から呼ばれることを想定。

        - moved_node が DateGridNode 自身なら → 子ノードを再レイアウト
        - それ以外のノードなら              → DateGrid へのスナップ / 解除を判定
        """
        # グリッドの一覧
        grids: List[DateGridNode] = [
            n for n in graph.all_nodes() if isinstance(n, DateGridNode)
        ]

        # グリッド自身が動いた場合 → 子ノードの再レイアウトだけ
        if isinstance(moved_node, DateGridNode):
            moved_node.layout_children()
            return

        # まず既存の親グリッドから外れていないか確認し、外れていたら解除
        for grid in grids:
            children: List[str] = grid.get_property("snap_nodes") or []
            if moved_node.id in children and not grid.is_inside(moved_node):
                grid.remove_snap_node(moved_node)

        # 次に、新しく入ったグリッドがあれば登録
        for grid in grids:
            if grid.is_inside(moved_node):
                grid.add_snap_node(moved_node)
                break
